
import { Route, Routes } from 'react-router-dom'
import './App.css'
import { Header } from './components/header'
import { Home } from './pages/Home'
import Footer from './components/footer'
import About from './pages/About'

import { useEffect } from "react";
import { useLocation } from "react-router-dom";

import ScentCategory from "./pages/ScentCategory";


function App() {

  function ScrollToTop() {
    const { pathname } = useLocation();

    useEffect(() => {
      window.scrollTo(0, 0);
    }, [pathname]);

    return null;
  }
  return (
    <>
      <ScrollToTop />
      <Header />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/scents/:category" element={<ScentCategory/>} />
        
      </Routes>

      <Footer />
    </>
  )
}

export default App
