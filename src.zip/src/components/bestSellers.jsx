
import { useState } from "react";
import Aqua_Dawn from "../../src/assets/Aqua_Dawn.jpeg"
import Wild_Desire from "../../src/assets/Wild_Desire.jpeg"
import Baked_Vanilla from "../../src/assets/Baked_Vanilla.jpeg"
import Forbidden_Bloom from "../../src/assets/Forbidden_Bloom.jpeg"

const Products = [
    {
        id: 1,
        img: Aqua_Dawn,
        name: "AQUA DAWN",
        category: "AQUA",
        gender: "UNISEX",
        usage: "FRESHNESS",
        rating: "4.5",
        price: "2000",
        sizes: "100 ML",
        badge: "Selling Fast"
    },
    {
        id: 2,
        img: Wild_Desire,
        name: "WILD DESIRE",
        category: "MUSK",
        gender: "UNISEX",
        usage: "SWEATY",
        rating: "4.6",
        price: "2000",
        sizes: "100 ML",
        badge: "Selling Fast"
    },
    {
        id: 3,
        img: Baked_Vanilla,
        name: "BAKED VANILLA",
        category: "SWEET",
        gender: "UNISEX",
        usage: "OUTING",
        rating: "4.6",
        price: "2000",
        sizes: "100 ML",
        badge: "Selling Fast"
    },
    {
        id: 4,
        img: Forbidden_Bloom,
        name: "FORBIDDEN BLOOM",
        category: "FRUITY",
        gender: "UNISEX",
        usage: "PARTY",
        rating: "4.5",
        price: "2500",
        sizes: "100 ML",
        badge: "Selling Fast"
    }
];

export function Featured() {

    const [selectedSizes, setSelectedSizes] = useState({});

    return (
        <section className="px-5 md:px-8 py-12">

            {/* Heading */}
            <div className="flex justify-between items-center mb-8">
                <h1 className="font-outfit text-3xl md:text-4xl">
                    FEATURED COLLECTION
                </h1>

                <button className="font-outfit text-sm hover:underline">
                    VIEW ALL →
                </button>
            </div>

            {/* Products */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">

                {Products.map((product) => (

                    <div
                        key={product.id}
                        className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition duration-300"
                    >

                        {/* Empty Image Area */}
                        <div className="relative h-64 overflow-hidden">

                            <img
                                src={product.img}
                                alt={product.name}
                                className="w-full h-full object-cover"
                            />

                            <span className="absolute top-4 left-4 bg-gray-800 text-white text-xs px-3 py-1 rounded-full">
                                ↗ {product.badge}
                            </span>

                        </div>

                        {/* Product Details */}
                        <div className="p-5">

                            <div className="flex justify-between items-center">
                                <h2 className="font-outfit text-sm font-medium">
                                    {product.name}
                                </h2>

                                <span className="text-xs whitespace-nowrap">
                                    <span className="text-orange-400">★</span> {product.rating}
                                </span>
                            </div>

                            <p className="text-gray-500 text-xs mt-1 tracking-wide">
                                {product.category} | {product.gender} | {product.usage}
                            </p>

                            <p className="font-outfit text-sm mt-2">
                                ₹{product.price}
                            </p>

                            {/* Size Selection */}
                            <div className="flex gap-2 mt-4">

                               <span  className="border border-gray-200 rounded-md px-2 py-2 text-xs">{product.sizes}</span>

                                <span className="border border-gray-200 rounded-md px-2 py-2 text-xs">
                                    ✥ Personalized
                                </span>

                            </div>

                            {/* Quick Add */}
                            <button
                                onClick={() =>
                                    alert(
                                        selectedSizes[product.id]
                                            ? `${product.name} - ${selectedSizes[product.id]} selected`
                                            : "Please select a size first"
                                    )
                                }
                                className="w-full bg-[#191919] text-white rounded-lg py-3 mt-4 text-sm font-semibold hover:bg-gray-700 transition"
                            >
                                Quick Add
                            </button>

                        </div>

                    </div>

                ))}

            </div>

        </section>
    );
}
