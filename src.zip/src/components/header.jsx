
import { Link } from "react-router-dom";
// import SearchIcon from "../../src/assets/search.png"
import { FiSearch } from "react-icons/fi";
// import ShoppingBagIcon from "../../src/assets/shopping-bag.png"
import { IoCart } from "react-icons/io5";
import Logo from "../../src/assets/Logo.png"
import hamburger from '../../src/assets/hamburger.png'
import { useState, useRef, useEffect } from "react"

export function Header() {

       const [menuOpen, setMenuOpen] = useState(false)

    const menuRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(event) {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setMenuOpen(false);
            }
        }

        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    return (
        <>
            <section className="sticky top-0 z-50 bg-white flex items-center justify-around py-5">
                <button type="button"
                        className="lg:hidden"
                        aria-label="Toggle navigation menu"
                        aria-expanded={menuOpen}
                        onClick={() => setMenuOpen(!menuOpen)} >
                        <img src={hamburger} alt="ham"
                            className="lg:hidden p-2 border-0 rounded hover:bg-gray-100 w-11 cursor-pointer shadow-2xl" />
                    </button>
                    
                <div className="flex items-center gap-3">
                   <Link to="/" ><img src={Logo} alt="Zayd Blend Logo" className="w-17 "/></Link>
                    <h1 className="font-bold text-2xl font-outfit w-20 md:w-fit">Zayd Blend</h1>
                </div>

                <div className=" items-center space-x-3 font-outfit text-lg tracking-wide font-light hidden lg:flex">
                    <Link to="/" className="hover:bg-black hover:text-white px-3 py-2 border-0 rounded-4xl">Home</Link>
                    <Link to="/signature-perfume" className="hover:bg-black hover:text-white px-3 py-2 border-0 rounded-4xl">Signature Perfume</Link>
                    <Link to="/personalized-perfume" className="bg-linear-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">Personalized Perfume</Link>
                    <Link to="/about" className="hover:bg-black hover:text-white px-3 py-2 border-0 rounded-4xl">About Us</Link>
                </div>

                <div className="flex gap-4 md:gap-8">
                    <button><FiSearch className="w-9 h-8 cursor-pointer"/>
                        {/* <img src={SearchIcon} alt="Search" className="w-7 cursor-pointer" /> */}
                    </button>
                    
                    <button><IoCart className="w-9 h-8 cursor-pointer"/>
                        {/* <img src={ShoppingBagIcon} alt="ShoppingBag" className="w-7 cursor-pointer"/> */}
                    </button>
                </div>

                
            </section>
            {menuOpen && (<nav>
                    <ul className=" lg:hidden px-5 py-3 w-full text-3xl font-outfit">
                        <li className="block py-3 text-gray-700 hover:underline"><Link to="/" onClick={() => setMenuOpen(false)}>Home</Link></li>
                        <li className="block py-3 text-gray-700 hover:underline"><Link to="/signature-perfume" onClick={() => setMenuOpen(false)}>Signature Perfume</Link></li>
                        <li className="block py-3 hover:underline bg-linear-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent"><Link to="/personalized-perfume" onClick={() => setMenuOpen(false)}>Personalized Perfume</Link></li>
                        <li className="block py-3 text-gray-700 hover:underline"><Link to="/about" onClick={() => setMenuOpen(false)}>About Us</Link></li>
                    </ul>
                </nav>)}
        </>
    );
}
