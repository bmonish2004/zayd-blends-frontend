
import { useParams } from "react-router-dom";
import Fresh from "../assets/Fresh.jpeg";
import Fruity from "../assets/Fruity.jpeg";
import musk from "../assets/musk.jpeg";
import sweet from "../assets/sweet.jpeg";

import aqua1 from "../assets/Aqua_Dawn.jpeg";
import aqua2 from "../assets/Wild_Desire.jpeg";
import aqua3 from "../assets/Woody.jpeg";
// import aqua4 from "../assets/";

const scentData = {
    aqua: {
        title: "Aqua Collection",
        description: "Fresh, aquatic fragrances that awaken your senses.",
        image: Fresh,
        products: [
      { id: 1, name: "Aqua Dawn", price: "₹2000", size: "100ml", image: aqua1 },
      { id: 2, name: "Wild Desire", price: "₹2000", size: "100ml", image: aqua2 },
      { id: 3, name: "Woody", price: "₹1,599", size: "100ml", image: aqua3 },
    //   { id: 4, name: "Coastal Wave", price: "₹1,799", size: "100ml", image: aqua4 },
    ],
    },
    fruity: {
        title: "Fruity Collection",
        description: "A vibrant blend of fruity and refreshing notes.",
        image: Fruity,
    },
    musk: {
        title: "Musk Collection",
        description: "Deep, warm and addictive fragrances.",
        image: musk,
    },
    sweet: {
        title: "Sweet Collection",
        description: "Indulge in sweet, creamy and delicious fragrances.",
        image: sweet,
    },
};

function ScentCategory() {
    const { category } = useParams();

    const scent = scentData[category?.toLowerCase()];

    if (!scent) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <h1 className="text-2xl">Collection not found</h1>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-white text-black">

            {/* Category Hero */}
            <section className="relative h-[350px] md:h-[450px] overflow-hidden">
                <img
                    src={scent.image}
                    alt={scent.title}
                    className="absolute inset-0 w-full h-full object-cover"
                />

                <div className="absolute inset-0 bg-black/50" />

                <div className="relative z-10 h-full flex flex-col justify-center items-center text-white text-center px-5">
                    <p className="text-xs tracking-[0.4em] mb-4">
                        ZAYD BLENDS
                    </p>

                    <h1 className="text-4xl md:text-6xl font-serif">
                        {scent.title}
                    </h1>

                    <p className="mt-5 text-sm md:text-base tracking-wide">
                        {scent.description}
                    </p>
                </div>
            </section>

            {/* Products Section */}
            <section className="max-w-7xl mx-auto px-5 md:px-10 py-16">
                <div className="text-center mb-12">
                    <p className="text-xs tracking-[0.3em] text-gray-500 mb-3">
                        FIND YOUR SIGNATURE SCENT
                    </p>

                    <h2 className="text-3xl md:text-4xl font-serif">
                        Explore {scent.title}
                    </h2>
                </div>

                {/* Product cards will go here */}
                <p className="text-center text-gray-500 pb-10">
                    Our Products
                </p>

                {/* 3 to 4 Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {scent.products.map((product) => (
            <div
              key={product.id}
              className="group border border-gray-200 flex flex-col justify-between overflow-hidden"
            >
              <div className="aspect-[3/4] overflow-hidden bg-gray-100">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="p-5 text-center">
                <h3 className="font-serif text-lg">{product.name}</h3>
                <p className="text-xs text-gray-500 tracking-widest mt-1">
                  {product.size}
                </p>
                <p className="mt-2 font-medium text-sm">{product.price}</p>
                <button className="mt-4 w-full py-2.5 bg-black text-white text-xs tracking-[0.2em] uppercase hover:bg-gray-800 transition-colors">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
            </section>

        </div>
    );
}

export default ScentCategory;
